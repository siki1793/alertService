package com.saikrishna.alertService.apimodel;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
public class CreateTeamResponse {
    private Boolean result;
}
