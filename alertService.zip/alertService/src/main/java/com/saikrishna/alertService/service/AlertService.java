package com.saikrishna.alertService.service;

import com.saikrishna.alertService.apimodel.CreateTeamRequest;
import com.saikrishna.alertService.apimodel.CreateTeamResponse;
import com.saikrishna.alertService.entities.Developer;
import com.saikrishna.alertService.entities.Team;
import com.saikrishna.alertService.repo.DeveloperRepo;
import com.saikrishna.alertService.repo.TeamRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Component
public class AlertService {

    @Autowired
    private DeveloperRepo developerRepo;

    @Autowired
    private TeamRepo teamRepo;

    public CreateTeamResponse createTeam(CreateTeamRequest request) {
        List<Developer> developerList = new ArrayList<>();
        if(!CollectionUtils.isEmpty(request.getDevelopers())) {
            for(CreateTeamRequest.Developer developer: request.getDevelopers()) {
                Developer d = Developer.builder()
                        .name(developer.getName())
                        .phoneNumber(developer.getPhoneNumber())
                        .build();
                developerList.add(d);
            }
            developerRepo.saveAll(developerList);
        }
        Team team = Team.builder()
                .name(request.getTeam().getName())
                .developers(developerList)
                .build();
        team = teamRepo.save(team);

        return CreateTeamResponse.builder()
                .result(true)
                .build();
    }



}
