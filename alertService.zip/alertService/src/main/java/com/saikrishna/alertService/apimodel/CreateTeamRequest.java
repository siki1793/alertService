package com.saikrishna.alertService.apimodel;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class CreateTeamRequest {
    private Team team;
    private List<Developer> developers;
    @AllArgsConstructor
    @NoArgsConstructor
    @Setter
    @Getter
    public static class Team {
        private String name;
    }
    @AllArgsConstructor
    @NoArgsConstructor
    @Setter
    @Getter
    public static class Developer {
        private String name;
        private String phoneNumber;
    }
}
