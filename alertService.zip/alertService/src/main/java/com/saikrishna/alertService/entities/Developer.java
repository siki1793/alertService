package com.saikrishna.alertService.entities;

import lombok.*;

import javax.persistence.*;

@Table
@Entity(name = "developer")
@Builder
@Setter
@Getter
@Data
@ToString
public class Developer {
    @Column(name = "id")
    @Id
    private Integer id;
    @Column(name = "name")
    private String name;
    @Column(name = "phone_number")
    private String phoneNumber;
}
