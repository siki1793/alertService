package com.saikrishna.alertService.entities;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Columns;
import org.hibernate.annotations.GeneratorType;

import javax.persistence.*;
import java.util.List;

@Table
@Entity(name= "team")
@Builder
@Setter
@Getter
@Data
public class Team {
    @Column(name = "id")
    @Id
    private Integer id;
    @Column(name = "name")
    private String name;
    @OneToMany
    private List<Developer> developers;
}
